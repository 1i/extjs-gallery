# gallery

Minified under the build/production/gallery
Still works without minification from root folder  
For icon serving use a web server  

### Features
Loads of info in the feeds.json  
good in grids and with some filters  

### Whats missing
Better CSS, better sass  
better assocations between phone, filterfeatures, categoryfeatures  
only between phone and filterfeatures exists  
npm script to run a local web server, works on linux not on windows  



Patrick O'Sullivan
https://github.com/1i/laughing-palm-tree



